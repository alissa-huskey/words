"""CLI module for words tool."""

from words.cli._ui import UI

__ALL__ = ["ui"]


ui = UI()
