# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['words', 'words.cli']

package_data = \
{'': ['*']}

install_requires = \
['click>=8.1.7,<9.0.0',
 'py-dict-client>=0.2.0,<0.3.0',
 'python-datamuse>=2.0.1,<3.0.0',
 'rich>=13.7.1,<14.0.0',
 'syllabifier @ git+https://github.com/dippedrusk/arpabet-syllabifier.git',
 'typer>=0.12.3,<0.13.0']

entry_points = \
{'console_scripts': ['words = words.cli.cli:main']}

setup_kwargs = {
    'name': 'words',
    'version': '0.1.0',
    'description': 'Simple wrapper for datamuse API.',
    'long_description': 'Words\n=====\n\nCLI tool to look up words using the [datamuse][datamuse] and [dict.org][dict] APIs.\n\n[datamuse]: https://www.datamuse.com/api/\n[dict]: http://dict.org\n\nUsage\n-----\n\n```\nwords -- Command line thesaurus, dictionary and more.\n\nCOMMANDS:\n  def   Get the definition of a word.\n  dict  Dict.org API commands.\n  dm    Datamuse word search.\n```\n\nFor more detailed usage `words [COMMAND] --help`.\n\nExamples\n--------\n\n``` bash\n$ words dm --ml homage --max 5\ncourt\nhonor\nhonoured\nrespect\nappreciation\n```\n\n``` bash\n$ words dm --rel-hom night\nknight\nnite\n```\n\n``` text\n$ words def homophone\n╭──── The Collaborative International Dictionary of English v.0.48 ─────╮\n│ Homophone \\Hom"o*phone\\, n. [Cf. F. homophone. See                    │\n│    {Homophonous}.]                                                    │\n│    1. A letter or character which expresses a like sound with         │\n│       another. --Gliddon.                                             │\n│       [1913 Webster]                                                  │\n│                                                                       │\n│    2. A word having the same sound as another, but differing          │\n│       from it in meaning and usually in spelling; as, all and         │\n│       awl; bare and bear; rite, write, right, and wright.             │\n│       Homophonic                                                      │\n╰───────────────────────────────────────────────────────────────────────╯\n╭─────────────────────── WordNet (r) 3.0 (2006) ────────────────────────╮\n│ homophone                                                             │\n│     n 1: two words are homophones if they are pronounced the same     │\n│          way but differ in meaning or spelling or both (e.g. bare     │\n│          and bear)                                                    │\n╰───────────────────────────────────────────────────────────────────────╯\n```\n\nStatus\n------\n\n**Pre-Alpha**\n\nUnsuited for not-me users.\n\nCredits\n------------\n\n* jams2/py-dict-client -- `dict://` client\n* gmarmstrong/python-datamuse -- datamuse client\n\nAlternatives\n------------\n\n* [datamuse-cli](https://pypi.org/project/datamuse-cli/) -- A very nice CLI to\n  datamuse. If I had seen this earlier I wouldn\'t have written this.\n',
    'author': 'Alissa Huskey',
    'author_email': 'alissa.huskey@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
