"""Words package."""


class WordsError(BaseException):
    """Words Exception."""
